from playsound import playsound
playsound('songs/happy.mp3')